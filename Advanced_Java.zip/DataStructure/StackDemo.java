import java.util.*;

public class StackDemo {

   public static void main(String args[]) {

      Stack st = new Stack();
	
      System.out.println("stack: " + st);
      
      int a=10;
      st.push(a);
      System.out.println("stack: " + st);

      st.push(20);
      System.out.println("stack: " + st);

      st.push(30);
      System.out.println("stack: " + st);

      int t = (int)st.pop();
      //int t = (int)st.pop();
      System.out.println(t);
      System.out.println("stack: " + st);
      

      boolean status= st.isEmpty();
      System.out.println("status: " + status);
      System.out.println("return from isEmpty(): " + st.isEmpty());

      int top= (int)st.peek();
      System.out.println("top element: " + top);
	
      int index = st.search(20);
      System.out.println("Index : " + index);
 	  
      index = st.search(50);
      System.out.println("Index : " + index);
 	
	   
   }
}
