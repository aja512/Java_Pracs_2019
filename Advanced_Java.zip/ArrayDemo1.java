public class ArrayDemo1
{
   public static void main(String []args) {
     							
		int arr[] = {3, 1, 2, 5, 4};

		for (int i = 0; i < arr.length; i++)
             		System.out.print(arr[i] + " ");

 		System.out.println();
		System.out.println("=====");
		
		// passing array to method sum 
		sum(arr);
		System.out.println("=====");
		
		// returning array to method 
		int r_arr[];
		r_arr=reverseArray(arr);
		for (int i = 0; i < r_arr.length; i++)
             		System.out.print(r_arr[i] + " ");
		System.out.println();
}

	public static void sum(int[] a) 
	{ 
		// getting sum of array values 
		int sum = 0; 
		
		for (int i = 0; i < a.length; i++) 
			sum+=a[i]; 
		
		System.out.println("sum of array values : " + sum); 

	} 

	static int[] reverseArray(int a[])
    	{
        	int temp;
          	int start=0;
		int end=a.length-1;
        	while (start < end)
        	{
        	    temp = a[start]; 
        	    a[start] = a[end];
        	    a[end] = temp;
        	    start++;
        	    end--;
        	} 
	return a;
    	}


}
