// A Java program to demonstrate differences between array 
// and ArrayList 
import java.util.ArrayList; 
import java.util.Arrays; 
class Test 
{ 
	public static void main(String args[]) 
	{ 
		/* ........... Normal Array............. */
		// Need to specify the size for array 
		int[] arr = new int[3]; 
		arr[0] = 1; 
		arr[1] = 2; 
		arr[2] = 3; 
		// We cannot add more elements to array arr[] 

		/*............ArrayList..............*/
		// Need not to specify size 
		ArrayList<Integer> arrL = new ArrayList<Integer>(); 
		arrL.add(1); 
		arrL.add(2); 
		arrL.add(3); 
		arrL.add(4); 
		// We can add more elements to arrL 

		System.out.println(arrL); 
		System.out.println(Arrays.toString(arr)); 
	} 
} 

