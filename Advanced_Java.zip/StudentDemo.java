class Student {

   int StudentAge;
   int rollNo;
   String name;
   
   public Student(int rollNo,String name)
	{
	this.rollNo= rollNo;
	this.name= name;         
	System.out.println("Roll no. is :" + rollNo);
	System.out.println("Name is :" + name);   
	} 

   public void setAge( int age ) {
      StudentAge = age;
   }

   public int getAge( ) {
      System.out.println("Student's age is :" + StudentAge );
      return StudentAge;
   }
}


public class StudentDemo
{
   public static void main(String []args) {
     							
     Student[] arr = new Student[4];
	arr[0] = new Student(1,"AAAA");
        arr[1] = new Student(2,"BBBB");
	arr[2] = new Student(3,"CCCC");
	arr[3] = new Student(4,"DDDD");
     	
	System.out.println("===="); 	
	for (int i = 0; i < arr.length; i++) 
            System.out.println("Element at " + i + " : " +arr[i].rollNo +" "+ arr[i].name); 

	System.out.println("====");      
	
	arr[0].setAge(21);
	arr[0].getAge();     
       
	
}
}
