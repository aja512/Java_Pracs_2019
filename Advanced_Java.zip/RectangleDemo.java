class Rectangle {
  int length;
  int breadth;

  Rectangle()
  {
  length  = 20;
  breadth = 10;
  }

  Rectangle(int len,int bre)
  {
  length  = len;
  breadth = bre;
  }

  Rectangle(int len,int bre, int scale)
  {
  length  = len * scale;
  breadth = bre * scale;
  }

 void setDiamentions()
  {
  length  = 40;
  breadth = 20;
  }
	
}

class RectangleDemo {
  public static void main(String args[]) {

  Rectangle r1 = new Rectangle();
  System.out.println("Length of R1 : " + r1.length);
  System.out.println("Breadth of R1 : " + r1.breadth);

  System.out.println("====");
  r1.setDiamentions();
  System.out.println("Length of new R1 : " + r1.length);
  System.out.println("Breadth of new R1 : " + r1.breadth);
  
  System.out.println("====");
  Rectangle r2 = new Rectangle(20,10);
  System.out.println("Length of R2 : " + r2.length);
  System.out.println("Breadth of R2 : " + r2.breadth);

  System.out.println("====");
  Rectangle r4 = new Rectangle(20,10,2);
  System.out.println("Length of R4 : " + r4.length);
  System.out.println("Breadth of R4 : " + r4.breadth);

	 System.out.println("Finalizing..." +r4.toString());
         r4.finalize();
         System.out.println("Finalized."+r4.toString());

  }
}
