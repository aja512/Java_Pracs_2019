
ArrayDemo		-  Declaring, Instantiation, Assignment and Display of Array
ArrayDemo1		-  Passing array to method and return array from method
multiDimensional	-  Declaring and Instantiation of 2D Array

JaggedArray		-  Irregular Size Array
DynamicArray		-  Usage of ArrayList
Test			-  Difference between Array and ArrayList

RecursionExample4       -  Recursion and Command Line Arguments
StudentDemo		-  Usage of getter and setter method
Autoboxing		-  WrapperClass and automatic conversion from primitive to wrapper object
Unboxing		-  automatic conversion from wrapper object to primitive datatype
