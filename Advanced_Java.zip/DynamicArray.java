// Program to demonstrate DynamicArray

import java.util.ArrayList;
class DynamicArray 
{ 
	public static void main(String[] args) 
	{ 
int   Integer
	//ArrayList a=new ArrayList();
	ArrayList<Integer> a = new ArrayList<Integer>();
	a.add(5);
	a.add(10);

	System.out.println(a.get(0)); 

	
	} 
} 

