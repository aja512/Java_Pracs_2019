interface Writable 
	{
		void write(String msg);
	}
public class StaticNestedClassExample
	{
	public static void main(String[] args)
	{
		Writable w1 = new Writable()
		{
		public void write(String msg)
		{
			System.out.println(msg);
		}
		};

		// Note the semicolon
	w1.write("Writing Diary");
	
	}
}

