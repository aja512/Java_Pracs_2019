import java.awt.*;
import java.awt.event.*;

public class AwtControlDemo {

   private Frame mainFrame;
   private Label headerLabel;
   private Label statusLabel;
   private Panel controlPanel;

   public AwtControlDemo(){
      prepareGUI();
   }

   public static void main(String[] args){
      AwtControlDemo  awtControlDemo = new AwtControlDemo();
     	 awtControlDemo.showLabelDemo();

}

   private void prepareGUI(){
      mainFrame = new Frame("Java AWT Examples");
      mainFrame.setSize(500,500);
      mainFrame.setLayout(new GridLayout(3, 2));

      mainFrame.addWindowListener(new WindowAdapter() 
	{
         	public void windowClosing(WindowEvent windowEvent)
		{
	            System.exit(0);
	         }        
      	});    

  
      mainFrame.setVisible(true);  
   }

   private void showLabelDemo()
{
      headerLabel = new Label();
      headerLabel.setText("AWT for SEIT: Label");      
      headerLabel.setAlignment(Label.CENTER);
      headerLabel.setSize(350,300);
      mainFrame.add(headerLabel);
   
   
      statusLabel = new Label();        
      statusLabel.setAlignment(Label.CENTER);
      statusLabel.setSize(350,100);
      mainFrame.add(statusLabel);
      


      controlPanel = new Panel();
      controlPanel.setLayout(new FlowLayout());
	
      Label l = new Label();
      l.setText("Welcome to demo on AWT Class.");
      l.setAlignment(Label.CENTER);
      l.setBackground(Color.GRAY);
      l.setForeground(Color.WHITE);
      controlPanel.add(l);
      
     

      Button okButton = new Button("OK");
      Button submitButton = new Button("Submit");
  
      okButton.addActionListener(new ActionListener() 
	{
           public void actionPerformed(ActionEvent e) 
		{
	            statusLabel.setText("Ok Button clicked.");
	         }
       });

      submitButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            statusLabel.setText("Submit Button clicked.");
         }
      });
  
      controlPanel.add(okButton);
      controlPanel.add(submitButton);
     
     
      mainFrame.add(controlPanel);
      mainFrame.setVisible(true);  
   }

}
