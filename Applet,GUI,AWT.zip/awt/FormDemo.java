import java.awt.*;
import java.awt.event.*;

public class FormDemo {

   private Frame mainFrame;
   private Label headerLabel;
   private Label statusLabel;
   private Panel controlPanel;
   String data="";
   public FormDemo()
   {
	mainFrame = new Frame("Java Form");
	mainFrame.setSize(700,800);
    mainFrame.setLayout(new GridLayout(4,1));
    mainFrame.addWindowListener(new WindowAdapter()
      {
        public void windowClosing(WindowEvent windowEvent)
          {
            System.exit(0);
          }
      });

    headerLabel = new Label();
    headerLabel.setAlignment(Label.LEFT);

    statusLabel = new Label();
    statusLabel.setAlignment(Label.CENTER);



   }

   public static void main(String[] args)
	{
	      FormDemo  awtControlDemo = new FormDemo();
	      awtControlDemo.showTextFieldDemo();
	}



   private void showTextFieldDemo()
	{

      headerLabel.setText("Registration");

      controlPanel = new Panel();
      controlPanel.setLayout(new GridLayout(6,2));

      Label  namelabel= new Label("User ID: ",Label.RIGHT);
      Label  passwordLabel = new Label("Password:",Label.RIGHT);
      Label  p1label= new Label("Language Known: ",Label.RIGHT);
      Label  p2label= new Label("Class: ",Label.RIGHT);
      Label  p3label= new Label("CSI Member?: ",Label.RIGHT);

      TextField userText = new TextField(6);
      TextField passwordText = new TextField(6);
      passwordText.setEchoChar('*');

      Panel p1=new Panel(new GridLayout(3,1));
      Checkbox l1 = new Checkbox("C");
      Checkbox l2 = new Checkbox("C++");
      Checkbox l3= new Checkbox("Java");
      p1.add(l1);
      p1.add(l2);
      p1.add(l3);

      l1.addItemListener(new ItemListener() {
         public void itemStateChanged(ItemEvent e) {
           data+= e.getStateChange()==1?"\nC Lang":"";

         }
      });

      l2.addItemListener(new ItemListener() {
         public void itemStateChanged(ItemEvent e) {
           data+= e.getStateChange()==1?"\nC++ Lang":"";

         }
      });

      l3.addItemListener(new ItemListener() {
         public void itemStateChanged(ItemEvent e) {
           data+= e.getStateChange()==1?"\nJava Lang":"";

         }
      });


      Panel p2=new Panel(new FlowLayout());
      Choice c=new Choice();
      c.add("SEIT");
      c.add("TEIT");
      c.add("BEIT");
      p2.add(c);


      Panel p3=new Panel(new FlowLayout());
      CheckboxGroup cbg = new CheckboxGroup();

      Checkbox checkBox1 = new Checkbox("Yes", cbg, true);
      Checkbox checkBox2 = new Checkbox("No", cbg, false);

      p3.add(checkBox1);
      p3.add(checkBox2);

      Button loginButton = new Button("Login");

      loginButton.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            data += "\n Username: " + userText.getText();
            data += "\n Password: " + passwordText.getText();
            data+= "\n Class: "+ c.getItem(c.getSelectedIndex());
            data+= "\n Language Known: ";
            data+= l1.getState()?"C Lang":"";
            data+= l2.getState()?"C++ Lang":"";
            data+= l3.getState()?"Java Lang":"";
            data+= "CSI Membership: "+cbg.getSelectedCheckbox().getLabel(); //()?"CSI":"Non-CSI";
            statusLabel.setText(data);
         }
      });

      controlPanel.add(namelabel);
      controlPanel.add(userText);
      controlPanel.add(passwordLabel);
      controlPanel.add(passwordText);
      controlPanel.add(p1label);
      controlPanel.add(p1);
      controlPanel.add(p2label);
      controlPanel.add(p2);
      controlPanel.add(p3label);
      controlPanel.add(p3);
      controlPanel.add(loginButton);

      mainFrame.add(headerLabel);
      mainFrame.add(controlPanel);
      mainFrame.add(statusLabel);

      mainFrame.setVisible(true);
   }
}
