import java.awt.*;
public class GLDemo extends Frame
{
  public GLDemo()
  {    Label statusLabel;
    setLayout(new GridLayout(3,4));
    setBackground(Color.red);
                        // create 12 anonymous button objects and add them
    for(int i = 0; i < 12; i++)
    {
      add(new Button("OK " + i));
    }
    statusLabel = new Label("Status Label");
    statusLabel.setAlignment(Label.CENTER);
    statusLabel.setSize(350,100);
    add(statusLabel);
    setSize(350, 300);
    setVisible(true);
  }
  public static void main(String args[])
  {
    new GLDemo();
  }
}
