import java.awt.*;
import java.awt.event.*;

public class LoginDemo {

   private Frame mainFrame;
   private Label headerLabel;
   private Label statusLabel;
   private Panel controlPanel;

   public LoginDemo()
   {
		mainFrame = new Frame("Java AWT Examples");
		mainFrame.setSize(500,500);
    mainFrame.setLayout(new GridLayout(4, 1));
    mainFrame.addWindowListener(new WindowAdapter()
      {
        public void windowClosing(WindowEvent windowEvent)
          {
            System.exit(0);
          }
      });

    headerLabel = new Label();
  //  headerLabel.setAlignment(Label.CENTER);

    statusLabel = new Label();
    statusLabel.setAlignment(Label.CENTER);

    mainFrame.add(headerLabel);
    mainFrame.add(statusLabel);

   }

   public static void main(String[] args)
	{
	      LoginDemo  awtControlDemo = new LoginDemo();
	      awtControlDemo.showTextFieldDemo();
	}



   private void showTextFieldDemo()
	{
      headerLabel.setText("Control in action: TextField");

      controlPanel = new Panel();
      controlPanel.setLayout(new FlowLayout());

      Label  namelabel= new Label("User ID: ");
      Label  passwordLabel = new Label("Password:");

      TextField userText = new TextField(6);
      TextField passwordText = new TextField(6);

      passwordText.setEchoChar('*');

      Button loginButton = new Button("Login");

      loginButton.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            String data = "Username: " + userText.getText();
            data += ", Password: " + passwordText.getText();
            statusLabel.setText(data);
         }
      });

      controlPanel.add(namelabel);
      controlPanel.add(userText);
      controlPanel.add(passwordLabel);
      controlPanel.add(passwordText);
      controlPanel.add(loginButton);

      mainFrame.add(controlPanel);
      mainFrame.setVisible(true);
   }
}
