import java.awt.*;
import java.awt.event.*;

public class AwtControlDemo2 {

   private Frame mainFrame;
   private Label headerLabel;
   private Label statusLabel;
   private Panel controlPanel;

   public AwtControlDemo2(){
      prepareGUI();
   }

   public static void main(String[] args){
      AwtControlDemo2  awtControlDemo = new AwtControlDemo2();
     	 awtControlDemo.showLabelDemo();
	// awtControlDemo.showCheckBoxDemo();
	// awtControlDemo.showButtonDemo();

}

   private void prepareGUI(){
      mainFrame = new Frame("Java AWT Examples");
      mainFrame.setSize(700,500);
      mainFrame.setLayout(new GridLayout(3,1));

      mainFrame.addWindowListener(new WindowAdapter() 
	{
         	public void windowClosing(WindowEvent windowEvent)
		{
	            System.exit(0);
	         }        
      	});    

  
      mainFrame.setVisible(true);  
   }

   private void showLabelDemo()
{
      headerLabel = new Label();
      headerLabel.setText("AWT for SEIT: Label");      
      headerLabel.setAlignment(Label.CENTER);
      headerLabel.setSize(250,300);
      mainFrame.add(headerLabel);
   
   
      statusLabel = new Label();        
      statusLabel.setAlignment(Label.CENTER);
      statusLabel.setSize(350,100);
      mainFrame.add(statusLabel);
      


      controlPanel = new Panel();
      controlPanel.setLayout(new GridLayout(3,2));
	
      Label l = new Label();
      l.setText("Welcome to demo on AWT Class.");
      l.setAlignment(Label.CENTER);
      l.setBackground(Color.GRAY);
      l.setForeground(Color.WHITE);
      controlPanel.add(l);
      
     

      Button okButton = new Button("OK");
      Button submitButton = new Button("Submit");
  
      okButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            statusLabel.setText("Ok Button clicked.");
         }
      });

      submitButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            statusLabel.setText("Submit Button clicked.");
         }
      });
  
      controlPanel.add(okButton);
      controlPanel.add(submitButton);
     


      Checkbox chkApple = new Checkbox("Apple");
      Checkbox chkMango = new Checkbox("Mango");
      Checkbox chkPeer = new Checkbox("Peer");


      chkApple.addItemListener(new ItemListener() {
         public void itemStateChanged(ItemEvent e) {             
            statusLabel.setText("Apple Checkbox: " 
            + (e.getStateChange()==1?"checked":"unchecked"));
         }
      });

      chkMango.addItemListener(new ItemListener() {
         public void itemStateChanged(ItemEvent e) {
            statusLabel.setText("Mango Checkbox: " 
            + (e.getStateChange()==1?"checked":"unchecked"));
         }
      });

      chkPeer.addItemListener(new ItemListener() {
         public void itemStateChanged(ItemEvent e) {
            statusLabel.setText("Peer Checkbox: " 
            + (e.getStateChange()==1?"checked":"unchecked"));
         }
      });

      controlPanel.add(chkApple);
      controlPanel.add(chkMango);
      controlPanel.add(chkPeer);  
	


    
      mainFrame.add(controlPanel);
     // mainFrame.add(statusLabel);
      
   
      mainFrame.setVisible(true);  
   }
/*
 private void showCheckBoxDemo(){

      headerLabel.setText("Control in action: CheckBox"); 

      Checkbox chkApple = new Checkbox("Apple");
      Checkbox chkMango = new Checkbox("Mango");
      Checkbox chkPeer = new Checkbox("Peer");


      chkApple.addItemListener(new ItemListener() {
         public void itemStateChanged(ItemEvent e) {             
            statusLabel.setText("Apple Checkbox: " 
            + (e.getStateChange()==1?"checked":"unchecked"));
         }
      });

      chkMango.addItemListener(new ItemListener() {
         public void itemStateChanged(ItemEvent e) {
            statusLabel.setText("Mango Checkbox: " 
            + (e.getStateChange()==1?"checked":"unchecked"));
         }
      });

      chkPeer.addItemListener(new ItemListener() {
         public void itemStateChanged(ItemEvent e) {
            statusLabel.setText("Peer Checkbox: " 
            + (e.getStateChange()==1?"checked":"unchecked"));
         }
      });

      controlPanel.add(chkApple);
      controlPanel.add(chkMango);
      controlPanel.add(chkPeer);       

      mainFrame.setVisible(true);  
   }
*/
/*
private void showButtonDemo(){
      headerLabel.setText("Control in action: Button"); 

      Button okButton = new Button("OK");
      Button submitButton = new Button("Submit");
      Button cancelButton = new Button("Cancel");

      okButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            statusLabel.setText("Ok Button clicked.");
         }
      });

      submitButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            statusLabel.setText("Submit Button clicked.");
         }
      });

      cancelButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            statusLabel.setText("Cancel Button clicked.");
         }
      });

      controlPanel.add(okButton);
      controlPanel.add(submitButton);
      controlPanel.add(cancelButton);       

      mainFrame.setVisible(true);  
   }
*/
}
