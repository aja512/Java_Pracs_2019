//import java.awt.event.MouseListener;
//import java.awt.event.MouseEvent;
import java.applet.Applet;
import java.awt.Graphics;

public class ExampleEventHandling extends Applet 
{
	String str;

   public void init() {
	str +="  intializing  ";
   	System.out.println(str);
  	repaint();   
}

   public void start() {
	str +="  Starting  ";   
   	System.out.println(str);
  	repaint();   
}

   public void stop() {
 	str +="  Stopping  ";   
   	System.out.println(str);
  	repaint();   
}


   public void destroy() {
  	str +="  destroy  ";
    	System.out.println(str);
  	repaint();   
}

   public void paint(Graphics g) {
      // Draw a Rectangle around the applet's display area.
     //	 g.drawRect(0, 0, getWidth() - 1, getHeight() - 1);

      // display the string inside the rectangle.
      //g.drawString(strBuffer.toString(), 10, 20);
	g.drawString(str, 10, 20);   
}


}
